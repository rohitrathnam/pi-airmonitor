#ifndef DMLC_BUILD_CONFIG_H_
#define DMLC_BUILD_CONFIG_H_

/* #undef FOPEN_64_PRESENT */

#if !defined(FOPEN_64_PRESENT) && DMLC_USE_FOPEN64
  #define DMLC_EMIT_FOPEN64_REDEFINE_WARNING
  #define fopen64 std::fopen
#endif

#endif  // DMLC_BUILD_CONFIG_H_
